this is a version of the project backported from labview 2023 to 2017

the vi is in:
2017 backport\Users\wtwinn\Desktop\EE-A438-Senior-Design\Project.vi

it was created from the latest version of the project as of this commit
https://github.com/Thermospore/EE-A438-Senior-Design/commit/c31ad25dd51d7590e5c58ffcfa20b611697a0a45